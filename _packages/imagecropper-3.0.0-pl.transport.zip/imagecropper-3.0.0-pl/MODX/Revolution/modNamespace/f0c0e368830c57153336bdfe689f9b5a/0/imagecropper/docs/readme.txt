--------------------
ImageCropper
--------------------
Version: 1.3.3
Author: Oene Tjeerd de Bruin
Contact: modx@sterc.nl
--------------------