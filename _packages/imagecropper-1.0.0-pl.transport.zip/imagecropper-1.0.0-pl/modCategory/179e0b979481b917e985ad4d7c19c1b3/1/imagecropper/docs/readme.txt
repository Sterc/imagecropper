--------------------
ImageCropper
--------------------
Author: Sterc <modx@sterc.nl>